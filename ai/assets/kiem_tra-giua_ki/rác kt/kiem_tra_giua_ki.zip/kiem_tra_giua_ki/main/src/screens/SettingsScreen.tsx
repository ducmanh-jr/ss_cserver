import React, { useState } from 'react';
import { 
  StyleSheet, Text, View, TouchableOpacity, ScrollView, 
  Switch, Platform, TextInput, Alert, ActivityIndicator 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useWeatherStore } from '../store/useWeatherStore';

import * as Location from 'expo-location';

export default function SettingsScreen({ navigation }: any) {
  const { 
    mockType, setMockType, 
    useMock, setUseMock
  } = useWeatherStore();

  const mockOptions = [
    { label: 'TRỜI NẮNG (NÓNG)', value: 'sunny' },
    { label: 'TRỜI MƯA (ẨM ƯỚT)', value: 'rainy' },
    { label: 'TRỜI LẠNH (RÉT)', value: 'cold' },
    { label: 'TRỜI MÂY (MÁT MẺ)', value: 'cloudy' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>CÀI ĐẶT</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>CẤU HÌNH HỆ THỐNG</Text>
          <View style={styles.row}>
            <View>
              <Text style={styles.label}>CHẾ ĐỘ GIẢ LẬP</Text>
              <Text style={styles.subLabel}>Chuyển đổi giữa dữ liệu thật (API) và giả lập</Text>
            </View>
            <Switch
              value={useMock}
              onValueChange={setUseMock}
              trackColor={{ false: '#EEE', true: '#000' }}
              thumbColor={Platform.OS === 'ios' ? '#FFF' : useMock ? '#FFF' : '#FFF'}
              ios_backgroundColor="#EEE"
            />
          </View>
        </View>

        {useMock && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>KỊCH BẢN THỬ NGHIỆM</Text>
            <Text style={styles.hint}>Mô phỏng các điều kiện thời tiết để kiểm tra gợi ý món ăn.</Text>
            {mockOptions.map((option) => (
              <TouchableOpacity
                key={option.value}
                style={styles.optionRow}
                onPress={() => setMockType(option.value)}
              >
                <Text style={[
                  styles.optionLabel,
                  mockType === option.value && styles.activeLabel
                ]}>
                  {option.label}
                </Text>
                {mockType === option.value && (
                  <Ionicons name="checkmark-circle" size={20} color="#000" />
                )}
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Manual Location Override removed as not in core requirements */}

        <View style={styles.footer}>
          <Text style={styles.footerText}>WEATHERFOODAPP v1.4.0</Text>
          <Text style={styles.footerSubText}>THIẾT KẾ CHO SỰ HOÀN HẢO</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  headerTitle: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 2,
    color: '#000',
  },
  backBtn: {
    padding: 8,
  },
  content: {
    padding: 24,
  },
  section: {
    marginBottom: 48,
  },
  sectionTitle: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.5,
    color: '#AAA',
    marginBottom: 24,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F5F5F5',
  },
  label: {
    fontSize: 14,
    fontWeight: '700',
    color: '#000',
    letterSpacing: 0.5,
  },
  subLabel: {
    fontSize: 12,
    color: '#AAA',
    marginTop: 4,
  },
  hint: {
    fontSize: 12,
    color: '#CCC',
    marginBottom: 24,
    fontStyle: 'italic',
  },
  optionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F5F5F5',
  },
  optionLabel: {
    fontSize: 13,
    color: '#888',
    letterSpacing: 1,
  },
  activeLabel: {
    color: '#000',
    fontWeight: '800',
  },
  footer: {
    marginTop: 40,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 9,
    fontWeight: '700',
    color: '#DDD',
    letterSpacing: 1,
  },
  footerSubText: {
    fontSize: 8,
    color: '#EEE',
    marginTop: 4,
    letterSpacing: 0.5,
  },
});
