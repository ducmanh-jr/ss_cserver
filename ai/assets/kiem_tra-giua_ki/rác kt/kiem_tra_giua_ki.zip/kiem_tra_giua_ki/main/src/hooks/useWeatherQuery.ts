import { useQuery } from '@tanstack/react-query';
import { fetchWeatherData } from '../api/weatherApi';
import { useWeatherStore } from '../store/useWeatherStore';
import { MOCK_WEATHER } from '../mock/mockWeatherData';

export const useWeatherQuery = (lat: number | null, lon: number | null) => {
  const { mockType, useMock } = useWeatherStore();

  return useQuery({
    queryKey: ['weather', lat, lon, mockType, useMock],
    queryFn: async () => {
      // Respect the dynamic toggle from the store
      if (useMock) {
        console.log(`Using Mock Data: ${mockType}`);
        // Simulate minor network delay for better UX feel
        await new Promise((resolve) => setTimeout(resolve, 500));
        return MOCK_WEATHER[mockType] || MOCK_WEATHER.sunny;
      }

      if (lat === null || lon === null) {
        throw new Error('Location coordinates are required for real data.');
      }

      console.log('Fetching real API data...');
      return fetchWeatherData(lat, lon);
    },
    // If mock is on, we don't need real coordinates to enable the query
    enabled: (!!lat && !!lon) || useMock,
    staleTime: 1000 * 60 * 5, // Cache for 5 minutes
  });
};
