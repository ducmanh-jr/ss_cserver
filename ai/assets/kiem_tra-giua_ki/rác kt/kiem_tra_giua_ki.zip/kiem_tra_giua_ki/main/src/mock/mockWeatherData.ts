export interface WeatherData {
  weather: {
    main: string;
    description: string;
    icon: string;
  }[];
  main: {
    temp: number;
    feels_like: number;
    humidity: number;
  };
  wind: {
    speed: number;
  };
  name: string;
}

export const MOCK_WEATHER: Record<string, WeatherData> = {
  sunny: {
    weather: [{ main: 'Clear', description: 'clear sky', icon: '01d' }],
    main: { temp: 35, feels_like: 37, humidity: 40 },
    wind: { speed: 5 },
    name: 'Mock Sunny City',
  },
  rainy: {
    weather: [{ main: 'Rain', description: 'moderate rain', icon: '10d' }],
    main: { temp: 24, feels_like: 25, humidity: 85 },
    wind: { speed: 3 },
    name: 'Mock Rainy City',
  },
  cold: {
    weather: [{ main: 'Mist', description: 'mist', icon: '50d' }],
    main: { temp: 14, feels_like: 12, humidity: 90 },
    wind: { speed: 2 },
    name: 'Mock Cold City',
  },
  cloudy: {
    weather: [{ main: 'Clouds', description: 'broken clouds', icon: '04d' }],
    main: { temp: 22, feels_like: 22, humidity: 60 },
    wind: { speed: 4 },
    name: 'Mock Cloudy City',
  },
};

export const ACTIVE_MOCK = MOCK_WEATHER.sunny;
