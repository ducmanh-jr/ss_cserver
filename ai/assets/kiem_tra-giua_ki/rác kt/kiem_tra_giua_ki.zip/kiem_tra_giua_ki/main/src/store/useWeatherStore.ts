import { create } from 'zustand';
import { WeatherData } from '../mock/mockWeatherData';
import { FoodItem } from '../utils/foodSuggestions';

interface WeatherState {
  weather: WeatherData | null;
  selectedFood: FoodItem | null;
  mockType: string;
  useMock: boolean;

  setWeather: (weather: WeatherData) => void;
  setSelectedFood: (food: FoodItem | null) => void;
  setMockType: (type: string) => void;
  setUseMock: (value: boolean) => void;
}

export const useWeatherStore = create<WeatherState>((set) => ({
  weather: null,
  selectedFood: null,
  mockType: 'sunny',
  useMock: process.env.EXPO_PUBLIC_USE_MOCK === 'true',

  setWeather: (weather) => set({ weather }),
  setSelectedFood: (food) => set({ selectedFood: food }),
  setMockType: (type) => set({ mockType: type }),
  setUseMock: (value) => set({ useMock: value }),
}));
