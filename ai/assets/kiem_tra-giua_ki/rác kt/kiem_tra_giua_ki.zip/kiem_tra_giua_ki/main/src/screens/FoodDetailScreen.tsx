import React from 'react';
import { 
  StyleSheet, Text, View, Image, ScrollView, 
  TouchableOpacity, Dimensions, StatusBar 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useWeatherStore } from '../store/useWeatherStore';

const { width } = Dimensions.get('window');

export default function FoodDetailScreen({ navigation }: any) {
  const { selectedFood } = useWeatherStore();

  if (!selectedFood) return null;

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      
      {/* Elegant Minimal Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>CHI TIẾT MÓN ĂN</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* Small, Sharp Image Frame */}
        <View style={styles.imageWrapper}>
          <View style={styles.imageFrame}>
            <Image 
              source={selectedFood.image} 
              style={styles.foodImage} 
              resizeMode="cover" // Fill the 4:3 frame beautifully
            />
          </View>
        </View>
        
        {/* Refined Content Section */}
        <View style={styles.content}>
          <Text style={styles.foodName}>{selectedFood.name}</Text>
          <View style={styles.divider} />
          
          <View style={styles.descSection}>
            <Text style={styles.sectionLabel}>MÔ TẢ NGẮN</Text>
            <Text style={styles.descriptionText}>{selectedFood.description}</Text>
          </View>
          
          <View style={styles.weatherTip}>
            <Ionicons name="bulb-outline" size={18} color="#666" />
            <Text style={styles.tipText}>
              Món ăn này được gợi ý dựa trên điều kiện thời tiết thực tế tại vị trí của bạn để đảm bảo trải nghiệm ẩm thực tốt nhất.
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* Professional Action Footer */}
      <View style={styles.footer}>
        <TouchableOpacity 
          style={styles.mainBtn} 
          activeOpacity={0.8}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.mainBtnText}>QUAY LẠI TRANG CHỦ</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F8F8F8',
  },
  headerTitle: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1,
    color: '#000',
  },
  backBtn: {
    padding: 8,
  },
  scrollContent: {
    paddingTop: 40,
    paddingBottom: 100,
  },
  imageWrapper: {
    alignItems: 'center',
    marginBottom: 32,
  },
  imageFrame: {
    width: width * 0.8,
    height: (width * 0.8) * 0.7, // 4:3 Ratio
    backgroundColor: '#F9F9F9',
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.1,
    shadowRadius: 15,
    elevation: 5,
  },
  foodImage: {
    width: '100%',
    height: '100%',
  },
  content: {
    paddingHorizontal: 32,
  },
  foodName: {
    fontSize: 26,
    fontWeight: '800',
    color: '#1A1A1A',
    textAlign: 'center',
    marginBottom: 20,
  },
  divider: {
    height: 1,
    backgroundColor: '#EEE',
    width: 60,
    alignSelf: 'center',
    marginBottom: 30,
  },
  descSection: {
    marginBottom: 32,
  },
  sectionLabel: {
    fontSize: 10,
    fontWeight: '700',
    color: '#BBB',
    letterSpacing: 1.5,
    marginBottom: 10,
    textAlign: 'center',
  },
  descriptionText: {
    fontSize: 15,
    lineHeight: 24,
    color: '#444',
    textAlign: 'center',
    paddingHorizontal: 10,
  },
  weatherTip: {
    flexDirection: 'row',
    backgroundColor: '#F9F9F9',
    padding: 18,
    borderRadius: 16,
    alignItems: 'center',
  },
  tipText: {
    flex: 1,
    marginLeft: 12,
    fontSize: 13,
    color: '#777',
    lineHeight: 20,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 24,
    backgroundColor: '#FFF',
  },
  mainBtn: {
    backgroundColor: '#000',
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mainBtnText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 1,
  },
});
