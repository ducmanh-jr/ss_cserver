import axios from 'axios';

const weatherApi = axios.create({
  baseURL: 'https://api.openweathermap.org/data/2.5',
  timeout: 10000,
});

export const fetchWeatherData = async (lat: number, lon: number) => {
  const apiKey = process.env.EXPO_PUBLIC_OPENWEATHER_API_KEY;
  if (!apiKey) {
    throw new Error('API Key is missing. Please check your .env file.');
  }

  const response = await weatherApi.get('/weather', {
    params: {
      lat,
      lon,
      appid: apiKey,
      units: 'metric',
    },
  });

  return response.data;
};

export default weatherApi;
