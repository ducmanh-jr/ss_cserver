import React, { useEffect, useState } from 'react';
import { 
  StyleSheet, Text, View, FlatList, TouchableOpacity, 
  Image, ActivityIndicator, StatusBar, RefreshControl 
} from 'react-native';
import * as Location from 'expo-location';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useWeatherQuery } from '../hooks/useWeatherQuery';
import { useWeatherStore } from '../store/useWeatherStore';
import { getFoodSuggestions, FoodItem } from '../utils/foodSuggestions';

export default function HomeScreen({ navigation }: { navigation: any }) {
  // Default to Hanoi to ensure immediate data availability
  const [location, setLocation] = useState({ lat: 21.0285, lon: 105.8542 });
  const [address, setAddress] = useState<string>('');
  const [isFetchingLocation, setIsFetchingLocation] = useState(false);
  const { setWeather, setSelectedFood, useMock } = useWeatherStore();

  const fetchLocation = async () => {
    setIsFetchingLocation(true);
    try {
      // On Web, calling getCurrentPosition directly often triggers the prompt better
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.log('Permission denied');
      }
      
      const lastKnown = await Location.getLastKnownPositionAsync({});
      if (lastKnown) {
        setLocation({ lat: lastKnown.coords.latitude, lon: lastKnown.coords.longitude });
      }

      // Lấy tọa độ GPS chính xác
      const locationPromise = Location.getCurrentPositionAsync({ 
        accuracy: Location.Accuracy.Balanced,
      });
      const timeoutPromise = new Promise<null>((_, reject) =>
        setTimeout(() => reject(new Error('timeout')), 6000)
      );

      const loc = await Promise.race([locationPromise, timeoutPromise]) as Location.LocationObject;
      const coords = { lat: loc.coords.latitude, lon: loc.coords.longitude };
      setLocation(coords);
      
      // Reverse Geocode
      const reverseLoc = await Location.reverseGeocodeAsync({
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude
      });
      
      if (reverseLoc.length > 0) {
        const item = reverseLoc[0];
        
        // Exhaustive address collection from all possible GPS fields
        const gpsParts = [
          item.streetNumber,
          item.street,
          item.name !== item.street ? item.name : null,
          item.district || item.subregion,
          item.city || item.region,
          item.country
        ].filter(Boolean);
        
        let finalAddress = [...new Set(gpsParts)].join(', ');
        
        // Final fallback: Ensure at least the city name from Weather API is there if GPS is sparse
        const cityName = weatherData?.name || '';
        if (cityName && !finalAddress.toLowerCase().includes(cityName.toLowerCase())) {
          finalAddress = finalAddress ? `${finalAddress}, ${cityName}` : cityName;
        }

        setAddress(finalAddress || 'Vị trí hiện tại');
      }
    } catch (e: unknown) {
      console.log('Location error:', e);
      if (!address || address.includes('Đang xác định')) {
        setAddress(weatherData?.name || 'Vị trí của bạn');
      }
    } finally {
      setIsFetchingLocation(false);
    }
  };

  useEffect(() => {
    fetchLocation();
  }, []);

  const { data: weatherData, isLoading, isError, error, refetch } = useWeatherQuery(location.lat, location.lon);

  // Sync address with city name from weather data when it arrives
  useEffect(() => {
    if (weatherData?.name && address) {
      const cityName = weatherData.name.toLowerCase();
      const currentAddress = address.toLowerCase();
      if (!currentAddress.includes(cityName)) {
        setAddress(prev => prev ? `${prev}, ${weatherData.name}` : weatherData.name);
      }
    }
  }, [weatherData, address]);

  useEffect(() => {
    if (weatherData) setWeather(weatherData);
  }, [weatherData]);

  const handleSelectFood = (food: FoodItem) => {
    setSelectedFood(food);
    navigation.navigate('FoodDetail');
  };

  // Only show spinner for initial data fetch
  if (isLoading && !weatherData) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="small" color="#000" />
      </View>
    );
  }

  // Handle Error state (like invalid API key)
  if (isError) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.errorContainer}>
          <Ionicons name="alert-circle-outline" size={32} color="#E74C3C" />
          <Text style={styles.errorTitle}>CONNECTION ERROR</Text>
          <Text style={styles.errorText}>{(error as Error).message || 'Unable to fetch weather data'}</Text>
          <TouchableOpacity 
            style={styles.retryBtn} 
            onPress={() => {
              fetchLocation();
              refetch();
            }}
          >
            <Text style={styles.retryBtnText}>RETRY</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // Helper to map weather to modern Ionicons
  const getWeatherIcon = (main: string) => {
    switch (main.toLowerCase()) {
      case 'clear': return 'sunny-outline';
      case 'clouds': return 'cloud-outline';
      case 'rain': 
      case 'drizzle': return 'rainy-outline';
      case 'thunderstorm': return 'thunderstorm-outline';
      case 'snow': return 'snow-outline';
      default: return 'partly-sunny-outline';
    }
  };

  const suggestions = weatherData ? getFoodSuggestions(weatherData) : [];

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      
      <View style={styles.header}>
        <View style={styles.locationContainer}>
          <TouchableOpacity 
            style={styles.locationBtn} 
            onPress={() => {
              fetchLocation();
              refetch();
            }}
            activeOpacity={0.6}
          >
            {isFetchingLocation 
              ? <ActivityIndicator size="small" color="#000" style={{ marginRight: 4 }} />
              : <Ionicons name="location-outline" size={14} color="#000" />
            }
            <Text style={styles.locationText}>
              {address || weatherData?.name || (isFetchingLocation ? 'Đang xác định...' : 'Vị trí của bạn')}
            </Text>
          </TouchableOpacity>
          <Text style={styles.dateText}>
            {new Date().toLocaleDateString('vi-VN', { weekday: 'long', month: 'short', day: 'numeric' }).toUpperCase()}
            {!useMock && `  ·  ${location.lat.toFixed(4)}°B, ${location.lon.toFixed(4)}°Đ`}
          </Text>
          {!useMock && <Text style={styles.tapHint}>Chạm để cập nhật vị trí</Text>}
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('Settings')}>
          <Ionicons name="ellipsis-horizontal" size={22} color="#000" />
        </TouchableOpacity>
      </View>

      <View style={styles.weatherSummary}>
        <View style={styles.tempRow}>
          <Text style={styles.tempText}>{Math.round(weatherData?.main?.temp || 0)}°</Text>
          <View style={styles.weatherInfo}>
            <View style={styles.statusRow}>
              <Ionicons name={getWeatherIcon(weatherData?.weather[0]?.main || '') as any} size={20} color="#000" style={{ marginRight: 8 }} />
              <Text style={styles.weatherMainText}>{weatherData?.weather[0]?.main || 'Clear'}</Text>
            </View>
            <Text style={styles.weatherDescText}>{weatherData?.weather[0]?.description}</Text>
          </View>
        </View>
        <View style={styles.weatherMetaRow}>
          <View style={styles.weatherMetaItem}>
            <Text style={styles.weatherMetaLabel}>ĐỘ ẨM</Text>
            <Text style={styles.weatherMetaValue}>{weatherData?.main?.humidity ?? '--'}%</Text>
          </View>
          <View style={styles.weatherMetaItem}>
            <Text style={styles.weatherMetaLabel}>CẢM GIÁC NHƯ</Text>
            <Text style={styles.weatherMetaValue}>{Math.round(weatherData?.main?.feels_like ?? 0)}°C</Text>
          </View>
          <View style={styles.weatherMetaItem}>
            <Text style={styles.weatherMetaLabel}>TỐC ĐỘ GIÓ</Text>
            <Text style={styles.weatherMetaValue}>{weatherData?.wind?.speed ?? '--'} m/s</Text>
          </View>
        </View>
      </View>

      <View style={styles.divider} />

      <View style={styles.listContainer}>
        <Text style={styles.sectionTitle}>MÓN ĂN GỢI Ý CHO BẠN</Text>
        <FlatList
          data={suggestions}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl 
              refreshing={isLoading && !!weatherData} 
              onRefresh={() => {
                fetchLocation();
                refetch();
              }}
              tintColor="#000"
            />
          }
          renderItem={({ item }) => (
            <TouchableOpacity 
              activeOpacity={0.7}
              style={styles.foodItem} 
              onPress={() => handleSelectFood(item)}
            >
              <Image source={item.image} style={styles.foodImage} />
              <View style={styles.foodContent}>
                <Text style={styles.foodName}>{item.name}</Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color="#DDD" />
            </TouchableOpacity>
          )}
          contentContainerStyle={styles.listPadding}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
  },
  locationContainer: {
    flex: 1,
  },
  locationBtn: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationText: {
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 1.5,
    marginLeft: 6,
  },
  dateText: {
    fontSize: 10,
    color: '#999',
    marginTop: 4,
    letterSpacing: 0.5,
  },
  tapHint: {
    fontSize: 9,
    color: '#CCC',
    marginTop: 4,
    letterSpacing: 0.5,
  },
  weatherMetaRow: {
    flexDirection: 'row',
    marginTop: 16,
  },
  weatherMetaItem: {
    marginRight: 28,
  },
  weatherMetaLabel: {
    fontSize: 9,
    fontWeight: '700',
    color: '#AAA',
    letterSpacing: 1,
  },
  weatherMetaValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#000',
    marginTop: 2,
  },
  weatherSummary: {
    paddingHorizontal: 24,
    paddingVertical: 20,
  },
  tempRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tempText: {
    fontSize: 64,
    fontWeight: '300',
    color: '#000',
    marginRight: 16,
  },
  weatherInfo: {
    justifyContent: 'center',
  },
  weatherMainText: {
    fontSize: 18,
    fontWeight: '600',
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  weatherDescText: {
    fontSize: 12,
    color: '#888',
    textTransform: 'capitalize',
  },
  divider: {
    height: 1,
    backgroundColor: '#F0F0F0',
    marginHorizontal: 24,
  },
  listContainer: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 24,
  },
  sectionTitle: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.5,
    color: '#AAA',
    marginBottom: 20,
  },
  foodItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },
  foodImage: {
    width: 60,
    height: 60,
    borderRadius: 2,
    backgroundColor: '#F9F9F9',
  },
  foodContent: {
    flex: 1,
    marginLeft: 16,
  },
  foodName: {
    fontSize: 15,
    fontWeight: '600',
    color: '#000',
  },
  foodDesc: {
    fontSize: 13,
    color: '#888',
    marginTop: 2,
  },
  listPadding: {
    paddingBottom: 40,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  errorTitle: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 2,
    marginTop: 16,
    color: '#E74C3C',
  },
  errorText: {
    fontSize: 13,
    color: '#888',
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 20,
  },
  retryBtn: {
    marginTop: 32,
    paddingHorizontal: 32,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#000',
  },
  retryBtnText: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1,
  }
});
