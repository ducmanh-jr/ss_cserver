import { WeatherData } from '../mock/mockWeatherData';

// Define a mapping for local assets to ensure they are properly bundled
const FOOD_ASSETS: Record<string, any> = {
  'Gỏi cuốn tôm thịt': require('../../assets/foods/Gỏi cuốn tôm thịt.jpg'),
  'Chè đá xanh': require('../../assets/foods/Chè đá xanh.jpg'),
  'Bún bò Huế': require('../../assets/foods/Bún bò Huế.jpg'),
  'Sinh tố bơ': require('../../assets/foods/Sinh tố bơ.jpg'),
  'Phở bò tái chín': require('../../assets/foods/Phở bò tái chín.jpg'),
  'Bánh mì nóng': require('../../assets/foods/Bánh mì nóng.jpg'),
  'Cháo gà': require('../../assets/foods/Cháo gà.jpg'),
  'Mì Quảng': require('../../assets/foods/Mì Quảng.jpg'),
  'Lẩu thái hải sản': require('../../assets/foods/Lẩu thái hải sản.jpg'),
  'Súp bí đỏ': require('../../assets/foods/Súp bí đỏ.jpg'),
  'Bánh bao nhân thịt': require('../../assets/foods/Bánh bao nhân thịt.jpg'),
  'Trà gừng mật ong': require('../../assets/foods/Trà gừng mật ong.jpg'),
  'Cơm tấm sườn bì chả': require('../../assets/foods/Cơm tấm sườn bì chả.jpg'),
  'Bún chả Hà Nội': require('../../assets/foods/Bún chả Hà Nội.jpg'),
  'Bánh xèo miền Trung': require('../../assets/foods/Bánh xèo miền Trung.jpg'),
  'Nước mía': require('../../assets/foods/Nước mía.jpg'),
};

export interface FoodItem {
  id: string;
  name: string;
  description: string;
  image: any; // Now using local assets (require results)
}

export const getFoodSuggestions = (weatherData: WeatherData): FoodItem[] => {
  const temp = weatherData.main.temp;
  const mainWeather = weatherData.weather[0].main.toLowerCase();
  const description = weatherData.weather[0].description.toLowerCase();

  // 1. Sunny (> 28°C or clear, sunny)
  if (temp > 28 || mainWeather === 'clear' || description.includes('sunny')) {
    return [
      { id: '1', name: 'Gỏi cuốn tôm thịt', description: 'Món cuốn tươi mát, nhẹ nhàng cho ngày nóng.', image: FOOD_ASSETS['Gỏi cuốn tôm thịt'] },
      { id: '2', name: 'Chè đá xanh', description: 'Món tráng miệng thanh mát giải nhiệt.', image: FOOD_ASSETS['Chè đá xanh'] },
      { id: '3', name: 'Bún bò Huế', description: 'Vị đậm đà, ăn vào ngày nắng cũng rất tuyệt.', image: FOOD_ASSETS['Bún bò Huế'] },
      { id: '4', name: 'Sinh tố bơ', description: 'Đồ uống béo ngậy, mát lạnh.', image: FOOD_ASSETS['Sinh tố bơ'] },
    ];
  }

  // 2. Rainy (rain, drizzle)
  if (mainWeather.includes('rain') || mainWeather.includes('drizzle')) {
    return [
      { id: '5', name: 'Phở bò tái chín', description: 'Nước dùng nóng hổi, ấm lòng ngày mưa.', image: FOOD_ASSETS['Phở bò tái chín'] },
      { id: '6', name: 'Bánh mì nóng', description: 'Bánh mì giòn rụm, thơm lừng.', image: FOOD_ASSETS['Bánh mì nóng'] },
      { id: '7', name: 'Cháo gà', description: 'Dễ tiêu, ấm áp cho ngày mưa ẩm.', image: FOOD_ASSETS['Cháo gà'] },
      { id: '8', name: 'Mì Quảng', description: 'Đặc sản đậm đà, hợp với không khí se lạnh.', image: FOOD_ASSETS['Mì Quảng'] },
    ];
  }

  // 3. Cold (< 18°C or mist, fog)
  if (temp < 18 || mainWeather === 'mist' || mainWeather === 'fog' || mainWeather === 'smoke' || mainWeather === 'haze') {
    return [
      { id: '9', name: 'Lẩu thái hải sản', description: 'Cay nồng, ấm áp cho ngày lạnh giá.', image: FOOD_ASSETS['Lẩu thái hải sản'] },
      { id: '10', name: 'Súp bí đỏ', description: 'Kem béo, bổ dưỡng và ấm áp.', image: FOOD_ASSETS['Súp bí đỏ'] },
      { id: '11', name: 'Bánh bao nhân thịt', description: 'Bánh bao nóng hổi vừa thổi vừa ăn.', image: FOOD_ASSETS['Bánh bao nhân thịt'] },
      { id: '12', name: 'Trà gừng mật ong', description: 'Thức uống giữ ấm cơ thể cực tốt.', image: FOOD_ASSETS['Trà gừng mật ong'] },
    ];
  }

  // 4. Default: Cloudy / Clouds
  return [
    { id: '13', name: 'Cơm tấm sườn bì chả', description: 'Món ăn quốc dân, hợp với mọi thời tiết.', image: FOOD_ASSETS['Cơm tấm sườn bì chả'] },
    { id: '14', name: 'Bún chả Hà Nội', description: 'Vị nướng thơm lừng, hấp dẫn.', image: FOOD_ASSETS['Bún chả Hà Nội'] },
    { id: '15', name: 'Bánh xèo miền Trung', description: 'Giòn tan, ăn kèm rau sống tươi ngon.', image: FOOD_ASSETS['Bánh xèo miền Trung'] },
    { id: '16', name: 'Nước mía', description: 'Đồ uống bình dân, giải khát hiệu quả.', image: FOOD_ASSETS['Nước mía'] },
  ];
};
